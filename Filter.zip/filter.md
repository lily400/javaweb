# LoginFilter 实现文档

## 1. 实现功能

`LoginFilter` 是一个 Servlet 过滤器，负责检查用户的登录状态。未登录用户在尝试访问受保护资源时会被重定向到登录页面。该过滤器确保只有经过身份验证的用户才能访问特定的应用程序资源。

## 2. 实现思路
### 2.1 首先创建两个登录页面
* `Login.html`(用于用户提交登录信息)
*  `main.html`(显示用户登录成功界面)
### 2.2 创建 `LoginServelt`类
- **2.2.1 实现接口：`javax.servlet.HttpServlet`**
- **2.2.2 作用：**  
***实现基本的用户身份验证，提供了一个简单的登录机制。成功登录后，用户信息被存储在 session 中，并且用户被重定向到主页面；
如果登录失败，则返回登录页面并显示错误信息。***
- **2.2.3 代码展示：**
```java
package com.gzu.Servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class LoginServlet extends HttpServlet{

    //模拟用户名和密码，定义为私有常量
    private final String validUsername="123456";
    private final String validPassword="123456";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {

        //获取用户名和密码
        String username=request.getParameter("username");
        String password=request.getParameter("password");

        //校验用户名和密码是否正确
        if(validUsername.equals(username) && validPassword.equals(password)){
            //1.登录成功 将用户信息保存到session
            //1.1创建session的固定格式
            HttpSession session=request.getSession();
            //1.2将用户名保存到session里
            session.setAttribute("user",username);

            //重定向主页面
            response.sendRedirect("/main.html");
        }else{
            response.sendRedirect("/login.html?error=1");
        }
    }
}
```
### 2.3 创建`LoginFilter`类
- **2.3.1 实现接口**：`javax.servlet.Filter`
- **2.3.2 作用**：***实现`doFilter`确保只有已登录的用户能够访问受保护的资源。如果用户未登录，
将被重定向到登录页面，而无需登录的路径将被允许直接访问。***
- **2.3.3 过滤逻辑：** ***在 `doFilter` 方法中，实现了以下逻辑：***

1. **获取请求路径**：通过 `HttpServletRequest` 获取当前请求的 URI。
2. **检查排除列表**：定义一个包含不需要登录的路径（如 `/login`、`/register`、`/public`）的列表。使用 `isExcludedPath` 方法检查当前请求路径是否在该列表中。
3. **登录状态检查**：
    - 如果请求路径在排除列表中，允许请求继续。
    - 如果请求路径不在排除列表中，检查用户的 session 中是否存在 `user` 属性。
    - 如果用户已登录，允许请求继续。
    - 如果用户未登录，重定向到登录页面。
- **2.3.5 代码展示：**
```java
package com.gzu.Filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@WebFilter("/")
public class LoginFilter  implements Filter {
    // 定义一个私有的、静态的、不可变的字符串列表，包含需要排除的路径
    private static final List<String> EXCLUDED_PATHS= Arrays.asList("/login.html", "/login", "/register.html", "/public");


    /**
     * 初始化方法
     * @param filterConfig
     * @throws ServletException
     */
    @Override
    public void init(FilterConfig filterConfig) throws ServletException{
        System.out.println("登录过滤。。。。。初始化。。。");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)throws IOException, ServletException {
        HttpServletRequest httpRequest=(HttpServletRequest) request;
        HttpServletResponse httpResponse=(HttpServletResponse) response;

        //获取请求的URI
        String requestURI=httpRequest.getRequestURI();

        //判断是否需要排除的列表请求中，如果是就直接允许通过
        if(isExcludedPath(requestURI)){
            chain.doFilter(request,response);
            return;
        }

        //获取当前用户的session
        HttpSession session=httpRequest.getSession(false);

        if(session!=null && session.getAttribute("user")!=null){
            chain.doFilter(request,response);
        }else{
            httpResponse.sendRedirect("/login.html");
        }
    }

    /**
     * 检查否需要排除的列表请求中
     * @param requestURI
     * @return
     */
    private boolean isExcludedPath(String requestURI){
        return EXCLUDED_PATHS.stream().anyMatch(requestURI::startsWith);
    }

    @Override
    public void destroy(){
        System.out.println("登录过滤。。。。。销毁了。。。");
    }
}
```


## 3. 结论

`LoginFilter` 提供了基本的登录验证功能，确保用户在访问受保护资源之前进行身份验证。通过扩展功能，可以进一步增强安全性和用户体验。
