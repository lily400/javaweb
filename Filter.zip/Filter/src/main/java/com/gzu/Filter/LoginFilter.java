package com.gzu.Filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@WebFilter("/")
public class LoginFilter  implements Filter {
    // 定义一个私有的、静态的、不可变的字符串列表，包含需要排除的路径
    private static final List<String> EXCLUDED_PATHS= Arrays.asList("/login.html", "/login", "/register.html", "/public");


    /**
     * 初始化方法
     * @param filterConfig
     * @throws ServletException
     */
    @Override
    public void init(FilterConfig filterConfig) throws ServletException{
        System.out.println("登录过滤。。。。。初始化。。。");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)throws IOException, ServletException {
        HttpServletRequest httpRequest=(HttpServletRequest) request;
        HttpServletResponse httpResponse=(HttpServletResponse) response;

        //获取请求的URI
        String requestURI=httpRequest.getRequestURI();

        //判断是否需要排除的列表请求中，如果是就直接允许通过
        if(isExcludedPath(requestURI)){
            chain.doFilter(request,response);
            return;
        }

        //获取当前用户的session
        HttpSession session=httpRequest.getSession(false);

        if(session!=null && session.getAttribute("user")!=null){
            chain.doFilter(request,response);
        }else{
            httpResponse.sendRedirect("/login.html");
        }
    }

    /**
     * 检查否需要排除的列表请求中
     * @param requestURI
     * @return
     */
    private boolean isExcludedPath(String requestURI){
        return EXCLUDED_PATHS.stream().anyMatch(requestURI::startsWith);
    }

    @Override
    public void destroy(){
        System.out.println("登录过滤。。。。。销毁了。。。");
    }
}
