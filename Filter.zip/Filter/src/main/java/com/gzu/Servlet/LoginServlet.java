package com.gzu.Servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class LoginServlet extends HttpServlet{

    //模拟用户名和密码，定义为私有常量
    private final String validUsername="123456";
    private final String validPassword="123456";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {

        //获取用户名和密码
        String username=request.getParameter("username");
        String password=request.getParameter("password");

        //校验用户名和密码是否正确
        if(validUsername.equals(username) && validPassword.equals(password)){
            //1.登录成功 将用户信息保存到session
            //1.1创建session的固定格式
            HttpSession session=request.getSession();
            //1.2将用户名保存到session里
            session.setAttribute("user",username);

            //重定向主页面
            response.sendRedirect("/main.html");
        }else{
            response.sendRedirect("/login.html?error=1");
        }
    }
}
