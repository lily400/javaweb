package com.gzu.Servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class LoginServlet extends HttpServlet {
    //# 创建user表，用于登陆验证
    //CREATE TABLE `user` (
    //  `id` int NOT NULL AUTO_INCREMENT,
    //  `name` varchar(20) NOT NULL,
    //  `password`  varchar(20) NOT NULL,
    //  PRIMARY KEY (`id`)
    //);
    //
    //# 插入数据
    //INSERT INTO `user` VALUES ('1', '张楚岚','123456');
    //INSERT INTO `user` VALUES ('2', '冯宝宝', '888');
    //INSERT INTO `user` VALUES ('3', '王也',  '666');
    //INSERT INTO `user` VALUES ('4', '陆玲儿', '999');

    private static final String URL = "jdbc:mysql://localhost:3306/user_demo?serverTimezone=GMT&characterEncoding=UTF-8";
    private static final String USER = "root";
    private static final String PASSWORD = "Aa2002175";


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 处理 GET 请求（如果需要）
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // 获取用户名和密码
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // 验证用户名和密码
        boolean isValidUser = validateUser(username, password);

        if (isValidUser) {
            // 登录成功，将用户信息保存到 session
            HttpSession session = request.getSession();
            session.setAttribute("user", username);

            // 重定向到主页面
            response.sendRedirect("/main.html");
        } else {
            // 登录失败，重定向回登录页面并显示错误信息
            response.sendRedirect("/login.html?error=1");
        }
    }

    private boolean validateUser(String username, String password) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement("SELECT id FROM user WHERE name = ? AND password = ?")) {

            // 设置参数
            ps.setString(1, username);
            ps.setString(2, password);

            // 打印查询语句和参数，用于调试
            System.out.println("Executing query: " + ps.toString());

            try (ResultSet rs = ps.executeQuery()) {
                // 检查是否有结果
                if (rs.next()) {
                    System.out.println("Login successful for user: " + username);
                    return true; // 用户存在且密码正确
                } else {
                    System.out.println("Login failed for user: " + username);
                    return false; // 用户不存在或密码错误
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }
}