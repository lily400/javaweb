package com.gzu;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletContext;
import java.io.IOException;

@WebServlet("/logs")
public class Servlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().println("<html><body><h1>Request Logs</h1>");

        // 从 ServletContext 获取日志信息
        ServletContext context = request.getServletContext();
        String logMessage = (String) context.getAttribute("logMessage");

        // 检查日志信息是否存在并显示
        if (logMessage != null) {
            response.getWriter().println("<pre>" + logMessage + "</pre>");
        } else {
            response.getWriter().println("<p>No logs available.</p>");
        }

        response.getWriter().println("</body></html>");
    }
}
