package com.gzu;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletContext;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;

// 使用@WebListener注解将该类声明为Servlet请求监听器
@WebListener
public class RequestLoggingListener implements ServletRequestListener {
    // 创建一个Logger实例，用于记录日志
    private static final Logger logger = Logger.getLogger(RequestLoggingListener.class.getName());
    // 创建一个SimpleDateFormat实例，用于格式化日期和时间
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    // 请求初始化时触发的方法
    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        // 在请求开始时，记录当前时间戳并存储在请求属性中
        sre.getServletRequest().setAttribute("startTime", System.currentTimeMillis());
        // 记录请求开始的时间到日志
        logger.info("Request started at: " + dateFormat.format(new Date()));
    }

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        // 将ServletRequest转换为HttpServletRequest，以便访问HTTP特有的方法
        HttpServletRequest httpRequest = (HttpServletRequest) sre.getServletRequest();

        // 获取请求开始时存储的时间戳，并计算请求处理的持续时间
        long startTime = (Long) httpRequest.getAttribute("startTime");
        long duration = System.currentTimeMillis() - startTime;

        // 获取客户端的IP地址、请求方法、请求URI、查询字符串和用户代理信息
        String clientIp = httpRequest.getRemoteAddr();
        String method = httpRequest.getMethod();  // 获取HTTP请求方法（GET、POST等）
        String requestURI = httpRequest.getRequestURI(); // 获取请求的URI
        String queryString = httpRequest.getQueryString(); // 获取查询字符串（如果存在）
        String userAgent = httpRequest.getHeader("User-Agent"); // 获取用户代理信息

        // 格式化日志消息，包含请求时间、IP、方法、URI、查询字符串、用户代理和处理时间
        String logMessage = String.format("[%s] [%s] [%s] [%s] [%s] [%s] [%d ms]",
                dateFormat.format(new Date()), clientIp, method, requestURI,
                queryString != null ? queryString : "-", userAgent != null ? userAgent : "-", duration);

        // 将日志信息存储在ServletContext中，以便后续访问
        ServletContext context = httpRequest.getServletContext();
        context.setAttribute("logMessage", logMessage);

        // 记录完整的请求日志到日志文件
        logger.info(logMessage);
    }
}
