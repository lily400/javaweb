# RequestLoggingListener

## 概述

`RequestLoggingListener` 是一个实现了 `ServletRequestListener` 接口的监听器，用于记录每个 HTTP 请求的详细信息。它在请求开始时记录时间，并在请求结束时计算请求处理时间。记录的信息包括请求时间、客户端 IP 地址、请求方法、请求 URI、查询字符串、用户代理及处理时间。

## 主要功能

- 记录请求的开始时间。
- 收集请求的相关信息，包括：
    - 客户端 IP 地址
    - 请求方法（GET, POST 等）
    - 请求 URI
    - 查询字符串（如果存在）
    - 用户代理
    - 请求处理时间（从请求开始到结束的时间）
- 将记录的信息输出到日志，方便后续分析。
## 注意事项
ServletContext 的使用：
ServletContext 是一个共享的上下文，适合存储全局信息。需考虑线程安全性，以免覆盖之前存储的信息。

## 代码实现

以下是 `RequestLoggingListener` 的实现代码：

```java
package com.gzu;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletContext;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;

@WebListener
public class RequestLoggingListener implements ServletRequestListener {
    private static final Logger logger = Logger.getLogger(RequestLoggingListener.class.getName());
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        sre.getServletRequest().setAttribute("startTime", System.currentTimeMillis());
        logger.info("Request started at: " + dateFormat.format(new Date()));
    }

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        HttpServletRequest httpRequest = (HttpServletRequest) sre.getServletRequest();
        long startTime = (Long) httpRequest.getAttribute("startTime");
        long duration = System.currentTimeMillis() - startTime;

        String clientIp = httpRequest.getRemoteAddr();
        String method = httpRequest.getMethod();
        String requestURI = httpRequest.getRequestURI();
        String queryString = httpRequest.getQueryString();
        String userAgent = httpRequest.getHeader("User-Agent");

        String logMessage = String.format("[%s] [%s] [%s] [%s] [%s] [%s] [%d ms]",
                dateFormat.format(new Date()), clientIp, method, requestURI,
                queryString != null ? queryString : "-", userAgent != null ? userAgent : "-", duration);

        ServletContext context = httpRequest.getServletContext();
        context.setAttribute("logMessage", logMessage);
        logger.info(logMessage);
    }
}
